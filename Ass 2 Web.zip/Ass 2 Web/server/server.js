
const express = require('express');
const axios = require('axios');

const app = express(); //экземпляр приложение
const PORT = 3000;

app.use(express.static('public'));


const apiKey = 'f74bf0e34432bc7b37985f647b7b3135';

//обработка маршрутов
app.get('/weather', async (req, res) => {
  try {
    const city = req.query.city || 'your_default_city';
    const weatherData = await getWeatherData(city);
    res.json(weatherData);
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});


async function getWeatherData(city) {
  const apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}`;
  const response = await axios.get(apiUrl);
  const temperatureCelsius = response.data.main.temp - 273.15;
  const feelsLikeCelsius = response.data.main.feels_like - 273.15;
  const forecastApiUrl = `https://api.openweathermap.org/data/2.5/forecast?q=${city}&appid=${apiKey}`;
  const forecastResponse = await axios.get(forecastApiUrl);

  const recentData = forecastResponse.data.list.find(entry => {
    const entryTimestamp = new Date(entry.dt * 1000);
    const threeHoursAgo = new Date(Date.now() - 3 * 60 * 60 * 1000);
    return entryTimestamp > threeHoursAgo;
  });


  return {
    ...response.data,
    main: {
      ...response.data.main,
      temp: temperatureCelsius.toFixed(2), 
      feels_like: feelsLikeCelsius.toFixed(2),
    },
    icon: response.data.weather[0].icon,
    feels_like: feelsLikeCelsius.toFixed(2),
    pressure: response.data.main.pressure,
    rain: recentData && recentData.rain ? recentData.rain['3h'] : 0,
  };
}



const geocodingApiKey = 'e42251497948c83e7ff56d8af8dbdf82';


app.get('/geocode', async (req, res) => {
  try {
    const city = req.query.city || 'your_default_city';
    const geocodeData = await getGeocodeData(city);
    res.json(geocodeData);
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});


async function getGeocodeData(city) {
  const geocodeApiUrl = `https://api.openweathermap.org/geo/1.0/direct?q=${city}&limit=1&appid=${geocodingApiKey}`;
  const response = await axios.get(geocodeApiUrl);
  return response.data[0];
}


const opencageApiKey = '9777c94566b544b69f3fad70be4489dd';


app.get('/location', async (req, res) => {
  try {
    const { lat, lon } = req.query;
    const locationData = await getLocationData(lat, lon);
    res.json(locationData);
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});

async function getLocationData(lat, lon) {
  const locationApiUrl = `https://api.opencagedata.com/geocode/v1/json?q=${lat}+${lon}&key=${opencageApiKey}`;
  const response = await axios.get(locationApiUrl);
  return response.data.results[0];
}

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});