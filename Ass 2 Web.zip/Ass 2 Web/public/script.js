document.addEventListener('DOMContentLoaded', () => {
  const cityNameInput = document.getElementById('cityNameInput');
  const cityInfo = document.getElementById('cityInfo');
  const weatherIcon = document.getElementById('weatherIcon');
  const weatherDetails = document.getElementById('weatherDetails');
  const latitude = document.getElementById('latitude');
  const longitude = document.getElementById('longitude');
  const city = document.getElementById('city');
  const state = document.getElementById('state');
  const country = document.getElementById('country');
  const formattedAddress = document.getElementById('formattedAddress');
  const mapContainer = document.getElementById('mapContainer');

 document.getElementById('getWeatherBtn').addEventListener('click', () => {
      const cityName = cityNameInput.value;

      fetch(`/weather?city=${cityName}`)
          .then(response => response.json())
          .then(weatherData => {
            latitude.style.display = 'inline'; 
            longitude.style.display = 'inline'; 
            locationDetails.style.display = 'block'; 
            
 
            cityInfo.innerHTML = `
            <h2 id="cityName">${weatherData.name}, ${weatherData.sys.country}</h2>
            <img id="weatherIcon" src="http://openweathermap.org/img/w/${weatherData.icon}.png" alt="Weather Icon">
            <p id="temperature" class="temperature">${weatherData.main.temp} °C</p>
`;

                    
                    weatherDetails.innerHTML = `
                    <div id="weatherInfo">
                        <p>☁️ ${weatherData.weather[0].description}</p>
                        <p>💧 ${weatherData.main.humidity}%</span></p>
                        <p>🌬️ ${weatherData.wind.speed} m/s</p>
                        <p>🌡️ ${weatherData.feels_like} °C</p>
                        <p>🔵 ${weatherData.pressure} hPa</p>
                        <p>🌧️ (last 3 hours): ${weatherData.rain} mm</p>
                    </div>
                `;

                // Получение описания погоды



                
              

              fetch(`/geocode?city=${cityName}`)
                  .then(response => response.json())
                  .then(geocodeData => {
                      latitude.textContent = geocodeData.lat;
                      longitude.textContent = geocodeData.lon;


                      

                      const map = L.map('mapContainer').setView([geocodeData.lat, geocodeData.lon], 10);
                      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                          attribution: '© OpenStreetMap contributors'
                      }).addTo(map);
                      L.marker([geocodeData.lat, geocodeData.lon]).addTo(map);

                      fetch(`/location?lat=${geocodeData.lat}&lon=${geocodeData.lon}`)
                          .then(response => response.json())
                          .then(locationData => {
                              city.textContent = locationData.components.city;
                              state.textContent = locationData.components.state;
                              country.textContent = locationData.components.country;
                              formattedAddress.textContent = locationData.formatted;
                          })
                          .catch(error => console.error(error));
                  })
                  .catch(error => console.error(error));
          })
          .catch(error => console.error(error));
  });
});
